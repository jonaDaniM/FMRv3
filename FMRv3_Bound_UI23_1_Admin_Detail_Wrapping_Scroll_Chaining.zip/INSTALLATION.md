# Bound UI 23.1 — Detail Wrapping and Scroll Chaining

## Scope

This is a stylesheet-only correction to Bound UI Release 23.

Replace:

```text
AdminQueueStyles.html
```

No changes are required to:

```text
Client.html
Index.html
Adapter.gs
appsscript.json
FMRCoreV3
Operational database
```

Keep:

```text
FMRCoreV3 library version: 22
Core semantic version: 3.0.0-alpha.22
```

## Corrections

### Admin inline detail wrapping

The inline detail row is inside the Admin register table. The register applies
`white-space: nowrap` to table cells, and that behavior was inherited by the
detail content.

This update explicitly applies normal wrapping within the inline detail row and
adds containment rules for Notes, metadata values, long descriptions, storage
locations, and detail-table content.

### Operational Queue scroll chaining

The prior queue list used:

```css
overscroll-behavior: contain;
```

That trapped wheel and touch scrolling inside the queue. The update enables
normal vertical scroll chaining:

1. The queue scrolls while more queue records are available.
2. At the top or bottom boundary, scrolling continues on the main page.
3. The pointer does not need to leave the Operational Queues panel.

Horizontal overscroll remains disabled.

## Deployment

1. Replace the complete `AdminQueueStyles.html`.
2. Save the standalone Bound project.
3. Create a new Bound project version.
4. Update the existing web deployment to that version.
5. Hard-refresh the browser or reopen it in an Incognito window.

## Acceptance tests

### Notes

1. Open an FMR containing a long Notes value.
2. Confirm the note wraps within the metadata card.
3. Confirm the inline detail panel does not widen beyond its designated area.
4. Confirm long storage locations and descriptions remain contained.
5. Confirm the materials table still supports horizontal scrolling.

### Queue scrolling

1. Place the pointer over the Operational Queue list.
2. Scroll through its records.
3. Continue scrolling after reaching the bottom.
4. Confirm the main page begins scrolling without moving the pointer.
5. Reverse direction at the top and confirm page scrolling continues upward.
6. Repeat with a trackpad or touch input when available.

## Suggested commit

```text
Fix Admin detail wrapping and queue scroll chaining
```
