# Sprint 5A alpha.19 — plain-text Size storage

## Root cause confirmed

The alpha.18 runtime diagnostic proved:

```text
The active normalizer is correct.
Literal date strings normalize correctly.
The live converted workbook parses FMR 42 as 5/8 and 1/2.
The persisted Bulk_Import_Lines rows contain Google date values.
```

Therefore the corruption occurs after parsing, when Google Sheets automatically
formats fraction strings written into database `Size` columns.

## Release

```text
Core: 3.0.0-alpha.19
Library: 19
Parser: ALPHA19_FRACTION_STORAGE_V1
Storage: PLAIN_TEXT_ALL_SIZE_COLUMNS
```

## Behavior

Alpha.19 discovers every database sheet defined in `FMR_V3_HEADERS` that has a
header named `Size` and applies the Google Sheets plain-text number format:

```text
@
```

This protects bulk-import, unpublished staging, published material lines, and
any other schema-managed Size column.

The format is enforced:

```text
During migration
Before bulk-import persistence
Before bulk-import staging
```

## Installation

### Core

Replace:

```text
FMRCoreV3/BulkImportService.gs
```

with:

```text
FMRCoreV3_BulkImportService_alpha19.gs
```

Apply:

```text
FMRCoreV3_Config_alpha19_patch.md
```

Run:

```javascript
migrateFmrV3BulkImport
runFmrV3BulkImportContractDiagnostic
```

Expected contract additions:

```text
version: 3.0.0-alpha.19
parserVersion: ALPHA19_FRACTION_STORAGE_V1
fractionStorageMode: PLAIN_TEXT_ALL_SIZE_COLUMNS
fractionStoragePassed: true
fractionStorageSheetCount: at least 2
```

Create immutable library version 19:

```text
3.0.0-alpha.19 — Preserve material Size fractions as plain text
```

### Bound

Replace:

```text
Bound/Adapter.gs
Bound/appsscript.json
```

with:

```text
Bound_Adapter_alpha19.gs
Bound_appsscript_alpha19.json
```

Update the existing web-app deployment.

No Client, Index, or Styles change is required.

## Create a clean K408A batch

Upload the unchanged K408A workbook again.

The parser-version change creates a new alpha.19 batch and supersedes the
incorrect alpha.18 batch.

Run:

```javascript
inspectFmrV3BulkImportBatch
```

Required:

```text
passed: true
parserVersion: ALPHA19_FRACTION_STORAGE_V1
worksheetCount: 49
proposedFmrCount: 49
totalLineCount: 228
unrepairedDateLikeSizeCount: 0
fractionStorage.passed: true
uomCounts.EA: 227
uomCounts.LF: 1
```

`fractionSizeRepairCount` may be `0` or `42`.

- `0` means the converted source already exposes clean fraction text.
- `42` means the parser repaired date-like source values.

Both are valid when `unrepairedDateLikeSizeCount` is zero.

## Repair FMR 42 staging

From the new alpha.19 batch:

1. Select FMR 42 only.
2. Select `Stage Selected FMRs`.
3. Reopen the existing unpublished staging record.

Expected active Size values:

```text
5/8
5/8
5/8
1/2
1/2
```

The prior incorrect staging lines remain superseded audit evidence.

## Final tests

Run:

```javascript
runFmrV3DataIntegrityDiagnostic
runFmrV3BulkImportContractDiagnostic
inspectFmrV3BulkImportBatch
verifyBoundBulkImportContractV3
verifyBoundFmrV3Connection
```

Do not publish FMR 42 until the active staging view contains only fraction text.
