# FMRCoreV3/Config.gs — alpha.19 fraction storage correction

Replace:

```javascript
VERSION: '3.0.0-alpha.18',
```

with:

```javascript
VERSION: '3.0.0-alpha.19',
```

Alpha.19 changes the database storage contract, not the fraction-recovery
algorithm. Run `migrateFmrV3BulkImport` after installing the Core files.
