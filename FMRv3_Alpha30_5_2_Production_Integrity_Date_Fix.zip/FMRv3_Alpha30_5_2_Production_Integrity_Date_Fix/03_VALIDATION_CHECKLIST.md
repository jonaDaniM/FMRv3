# 03 — Alpha 30.5.2 Validation Checklist

Use this checklist after applying the one-time repair and after deploying the
new immutable Core version.

## A. Release identity

- [ ] Production portal says `FMRCore 3.0.0-alpha.30.5.2`.
- [ ] Environment says `PRODUCTION`.
- [ ] Transaction mode says `ENABLED`.
- [ ] Database fingerprint remains `Pbbv5bSG3STZ`.
- [ ] Bound uses the newly created immutable Core library version.
- [ ] GitHub is updated only after validation succeeds.

## B. Backup

- [ ] `applyAlpha30_5_2ProductionRepair()` returned `backup.success: true`.
- [ ] Backup_History contains the Alpha 30.5.2 pre-repair backup.
- [ ] Backup row is SUCCESS and Active YES.

## C. FMR 209 integrity repair

- [ ] FMR 209 target line is still 3 EA pending.
- [ ] Keeper request remains active:
      `BACKORDER-4622291F-A57C-4B66-B68F-BD82AD37DCBB`.
- [ ] Orphan request is inactive:
      `BACKORDER-49F182BB-C569-402C-9617-1DFF70D94A5A`.
- [ ] Orphan historical row was not deleted.
- [ ] Operational_Index has no active row whose Entity_ID is the orphan request.
- [ ] `postIntegrity.passed` is true.
- [ ] `postIntegrity.lineIssueCount` is 0.
- [ ] `postIntegrity.headerIssueCount` is 0.
- [ ] `postIntegrity.bagIndexIssueCount` is 0.

## D. Operational Readiness

- [ ] Refresh Operations no longer shows the contradictory
      `FAIL + controls are healthy` message.
- [ ] If Overall Health is FAIL, the summary names Schema, Integrity, or System
      Control as the failing area.
- [ ] If all hard controls pass and there are no stale/backup warnings, Overall
      Health is PASS.
- [ ] Stale B/O reflects actual aged pending requests only.
- [ ] Stale Bags reflects actual aged active Bag items only.

## E. Date repair

- [ ] FMR 653 = 2026-07-24.
- [ ] FMR 666 = 2026-07-21.
- [ ] FMR 670 = 2026-07-27.
- [ ] FMR 791 = 2026-08-10.
- [ ] FMR 811 = 2026-08-18.
- [ ] FMR 930 = 2026-08-27.
- [ ] The same dates appear in both Import_Staging_Header and FMR_Header.
- [ ] Audit_Log contains `ALPHA30_5_2_DATE_REQUIRED_REPAIR` entries.
- [ ] FMR 803 was not automatically changed.

## F. New-import Date Required test

- [ ] Source workbook Date Required is known.
- [ ] Bulk_Import_Items preserves it.
- [ ] Import_Staging_Header preserves it.
- [ ] FMR_Header preserves it after publish.
- [ ] No 1969 date is created.
- [ ] An invalid/suspicious date is blocked rather than defaulted.

## G. Backorder regression test

Use a controlled line with remaining unlocated requirement.

- [ ] Submit one normal backorder.
- [ ] Exactly one Backorder_Requests row is created.
- [ ] One BACKORDER_REQUESTED Material_Transactions row exists.
- [ ] FMR_Line_Items Qty_Pending_Backorder matches active request Qty_Pending.
- [ ] Admin queue shows the request once.
- [ ] Admin Confirm/Reject/Return still works.

### Guard test

Do not intentionally corrupt Production.

The guard is considered verified if a line with inconsistent request-table and
line-state totals receives an error beginning:

`Backorder integrity guard blocked this submission...`

and no new Backorder_Request is created.

Test that behavior in TEST if you want to deliberately create a mismatch.

## H. Final Production acceptance

- [ ] Run Operational Health Check.
- [ ] Create one manual backup after deployment.
- [ ] Open Field search.
- [ ] Open Admin register.
- [ ] Open Backorder queue.
- [ ] Open Active Bag queue.
- [ ] Open Owner staging.
- [ ] No new Apps Script errors appear in Executions.
- [ ] Commit the final source to GitHub.
