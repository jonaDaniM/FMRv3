# 01 — Implementation Instructions

## Baseline

Use these instructions only if the FMRCoreV3 source is still based on GitHub
commit `771412f8f0f04f4f70d1ffd5e3460ffbec67b5e8` or the equivalent deployed
Alpha 30.5 code.

Before editing, confirm the Core header currently shows:

`VERSION: '3.0.0-alpha.30.5'`

and the Bound project currently references Core library version 37.

Do not change the Production database ID, schema, or header contracts as part
of this package.

---

## Step 1 — Add the new Core hardening file

Open the standalone **FMRCoreV3** Apps Script project.

Create a new script file named:

`Alpha30_5_2_ProductionHardening.gs`

Copy the **entire contents** of:

`FMRCoreV3/ADD_Alpha30_5_2_ProductionHardening.gs`

into that new Apps Script file.

Save.

This file must remain in Core after the one-time repair because the permanent
Owner and Field functions call two helpers from it:

- `normalizeStageDateRequiredAlpha30_5_2_`
- `assertBackorderRequestParityBeforeSubmitAlpha30_5_2_`

---

## Step 2 — Replace the staging validator in OwnerService.gs

Open:

`FMRCoreV3/OwnerService.gs`

Search for:

`function validateStagePayloadFmrV3_(`

Delete that function from its opening line through its closing `}` only.

Do **not** delete `saveStagedFmrFmrV3_` or any function below it.

Paste the complete function from:

`FMRCoreV3/REPLACE_validateStagePayloadFmrV3_.gs`

Save.

### What changed

Only the Date Required normalization changed.

Old behavior:

`new Date(`${source.dateRequired}T12:00:00`)`

New behavior:

`normalizeStageDateRequiredAlpha30_5_2_(source.dateRequired)`

No material-line arithmetic, staging schema, publication schema, or UOM logic
changes.

---

## Step 3 — Replace Field backorder submission in FieldService.gs

Open:

`FMRCoreV3/FieldService.gs`

Search for:

`function submitBackorderFmrV3_(`

Delete that complete function only.

Paste the complete function from:

`FMRCoreV3/REPLACE_submitBackorderFmrV3_.gs`

Save.

### What changed

Before creating a Backorder_Request, the function now verifies:

`FMR_Line_Items pending/confirmed == active Backorder_Requests pending/confirmed`

If the values do not agree, it throws an error **before another request is
created**.

This specifically prevents a user retry from turning a partially completed
request into a second active request.

It does not change valid backorder quantities, Admin review logic, or returned
backorder behavior.

---

## Step 4 — Bump the Core version

Open:

`FMRCoreV3/Config.gs`

Change exactly:

`VERSION: '3.0.0-alpha.30.5',`

to:

`VERSION: '3.0.0-alpha.30.5.2',`

Save.

Do not change `DEFAULT_DATABASE_ID`.

---

## Step 5 — Fix the Bound Operational Readiness explanation

Open the standalone **Bound** Apps Script web-app project.

Open:

`Client.html`

Follow the exact search-and-replace instructions in:

`Bound/REPLACE_Operational_Readiness_Fail_Message.txt`

There are two edits:

1. add `operationalHealthFailureMessagesV3_()` immediately before
   `renderOperationsCenterV3_()`;
2. replace the existing `operationsHealthSummary` assignment block.

Save.

This is a display-only correction. It does not alter PASS/WARN/FAIL decisions.

---

## Step 6 — Save everything, but do NOT publish the new library yet

At this point:

- Core source contains the permanent fixes;
- Bound source contains the clearer FAIL explanation;
- Production data has **not yet been changed**.

Now execute the one-time Production repair from the Core editor using the
runbook in `02_PRODUCTION_REPAIR_RUNBOOK.md`.

The repair functions explicitly target Production database:

`1dB9drNelT2D9OCy6tUyzGrqta4CBFC6P-x2WTlCLb4E`

and refuse to run unless its runtime fingerprint is:

`Pbbv5bSG3STZ`

---

## Step 7 — After the Production repair passes, create a new immutable Core version

Create the next immutable FMRCoreV3 library version using the same process you
have used for prior releases.

Version 37 is the current Bound reference, so if no other version was created
after it, the new library version should be 38.

Do not assume 38 if the Apps Script project shows a later version; use the
actual newly created immutable version.

---

## Step 8 — Point Bound to the new Core library version

In the Bound project, update the FMRCoreV3 library dependency from version 37
to the new Alpha 30.5.2 Core version.

If you manage the dependency through the Apps Script Libraries UI, update it
there.

If you also maintain the manifest in GitHub, the corresponding
`Bound/appsscript.json` change is:

Old:

`"version": "37"`

New:

`"version": "<NEW_CORE_LIBRARY_VERSION>"`

Do not change:

- `userSymbol`
- `libraryId`
- `executeAs`
- `access`
- OAuth scopes.

---

## Step 9 — Redeploy Bound

Create a new version of the existing Bound web-app deployment.

Do not create a second Production web-app URL unless that is intentional.

Confirm the existing Production URL now shows in the page subtitle:

`FMRCore 3.0.0-alpha.30.5.2`

---

## Step 10 — GitHub synchronization

After Production validation succeeds, update the repository so GitHub matches
the deployed source.

Repository:

`jonaDaniM/FMRv3`

Recommended commit message:

`Alpha 30.5.2 production date and integrity hardening`

GitHub changes should include:

- ADD `FMRCoreV3/Alpha30_5_2_ProductionHardening.gs`
- UPDATE `FMRCoreV3/OwnerService.gs`
- UPDATE `FMRCoreV3/FieldService.gs`
- UPDATE `FMRCoreV3/Config.gs`
- UPDATE `Bound/Client.html`
- UPDATE `Bound/appsscript.json` to the actual new Core library version

Do not commit the package's `REPLACE_*.gs` helper files into the live
FMRCoreV3 folder. They are implementation aids; GitHub should contain the
actual modified production files.
