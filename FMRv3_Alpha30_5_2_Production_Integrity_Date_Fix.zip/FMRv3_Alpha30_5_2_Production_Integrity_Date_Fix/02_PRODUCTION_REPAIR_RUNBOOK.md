# 02 — Production Repair Runbook

## Purpose

This one-time repair corrects the two verified Production data problems:

1. retire the orphan duplicate Backorder_Request for FMR 209 without changing
   the correct 3 EA pending line state;
2. restore Date Required for the 19 FMRs whose source date is verified but
   whose staging/published date became 1969.

The Apply function creates a fresh Production database backup **before** it
writes either repair.

---

# Phase A — Read-only Preview

In the **FMRCoreV3 Apps Script editor**, choose this function from the Run
dropdown:

`previewAlpha30_5_2ProductionRepair`

Run it.

Authorize if Google prompts for permissions.

Open **Execution log** and inspect the returned/logged JSON.

## Required Preview conditions

The top-level output should show:

- `passed: true`
- `readOnly: true`
- `version: "3.0.0-alpha.30.5.2"`
- `environment: "PRODUCTION"`
- `databaseFingerprint: "Pbbv5bSG3STZ"`

### Date repair

If none of the 19 known dates were manually fixed after this package was
created, expected:

- `dateRepair.count: 19`
- `dateRepair.eligible: 19`
- `dateRepair.alreadyCorrect: 0`
- `dateRepair.blocked: 0`

If some were already correctly repaired, that is also acceptable:

`eligible + alreadyCorrect = 19`

but **blocked must equal 0**.

For every record, confirm:

- `expectedSourceDate` is correct;
- `sourceEvidence.unambiguous` is `true`;
- `sourceEvidence.dateRequired` equals `expectedSourceDate`;
- `blocked` is `false`.

### FMR 209 orphan

Expected on the first run:

- `orphanBackorder.fmrNumber: "209"`
- `linePending: 3`
- `orphanActive: true`
- `keeperActive: true`
- `orphanTransactionCount: 0`
- `keeperTransactionCount >= 1`
- `eligible: true`
- `blocked: false`

If the orphan was already manually retired correctly, acceptable:

- `eligible: false`
- `alreadyCorrect: true`
- `blocked: false`

## STOP conditions

Do not run Apply if either is true:

- `dateRepair.blocked > 0`
- `orphanBackorder.blocked == true`

The Apply function also rechecks these conditions, but Preview is the human
review gate.

---

# Phase B — Apply the Production repair

Once Preview is clean, choose:

`applyAlpha30_5_2ProductionRepair`

Run it once.

The function acquires the same ScriptLock used by Field operations so a Field
write cannot overlap the repair.

It then:

1. verifies Production environment/fingerprint again;
2. reruns all preconditions;
3. creates a fresh Production database backup;
4. repairs eligible 1969 Date Required records;
5. retires the orphan FMR 209 Backorder_Request if still eligible;
6. deactivates any active Operational_Index records for the orphan request;
7. reconciles Field notifications for the FMR 209 line;
8. refreshes the FMR 209 header aggregate;
9. writes Audit_Log entries;
10. reruns the full data-integrity diagnostic;
11. calculates current Operational Readiness.

## Expected Apply output

First successful run should normally show:

- `success: true`
- `alreadyApplied: false`
- `environment: "PRODUCTION"`
- `databaseFingerprint: "Pbbv5bSG3STZ"`
- `backup.success: true`
- `dateRepairCount: 19`
- `orphanBackorder.applied: true`
- `postIntegrity.passed: true`
- `postIntegrity.lineIssueCount: 0`
- `postIntegrity.headerIssueCount: 0`
- `postIntegrity.bagIndexIssueCount: 0`

Because the Production screenshot showed stale backorders = 0 and stale bags =
0, `postHealth.overallStatus` should normally resolve to PASS if no new issue
appeared while this package was being prepared.

If a new operational warning appeared independently, postHealth may be WARN
while integrity still passes. That is not a failure of this repair.

## Idempotency

A second run is safe.

If everything was already repaired, it should return:

- `success: true`
- `alreadyApplied: true`
- no second date write
- no second orphan retirement.

A second backup is not created when there are no remaining changes.

---

# Phase C — Spot-check the database before publishing the new library

Open the Production database.

## FMR 209

In `FMR_Line_Items`, verify the target line still says:

- FMR 209
- commodity `5FSH8-A-L-1`
- requested = 3
- pending backorder = 3
- confirmed backorder = 0
- not yet located = 3
- remaining = 3

In `Backorder_Requests`, verify:

Keeper:

`BACKORDER-4622291F-A57C-4B66-B68F-BD82AD37DCBB`

remains active.

Orphan:

`BACKORDER-49F182BB-C569-402C-9617-1DFF70D94A5A`

is inactive and status is `Voided`.

Do not delete either historical row.

## Date Required

Spot-check at least:

- FMR 653 → 2026-07-24
- FMR 666 → 2026-07-21
- FMR 670 → 2026-07-27
- FMR 791 → 2026-08-10
- FMR 811 → 2026-08-18
- FMR 930 → 2026-08-27

Check both:

- `Import_Staging_Header`
- `FMR_Header`

The date should agree in both tables.

---

# Phase D — Publish and verify through the portal

After the data repair passes:

1. create the new immutable Core library version;
2. point Bound to it;
3. redeploy Bound;
4. open Owner → Operational Readiness;
5. click **Refresh Operations**;
6. click **Run Health Check**.

Expected:

- Overall Health = PASS, unless a new independent warning/failure exists;
- Stale B/O = 0 if still current;
- Stale Bags = 0 if still current;
- explanatory text = `Schema, integrity, and system controls are healthy.`;
- subtitle shows `FMRCore 3.0.0-alpha.30.5.2`.

---

# Phase E — Prove the Date Required fix with one controlled import

Use a small FMR workbook that contains a clearly visible Date Required.

Recommended:

- use one FMR only;
- choose an unused FMR number;
- make the source date easy to recognize;
- do not use a live material package if a controlled test FMR is available.

Process:

1. Bulk Import / preview.
2. Confirm `Bulk_Import_Items.Date_Required`.
3. Stage the FMR.
4. Confirm `Import_Staging_Header.Date_Required` is the **same date**.
5. Publish.
6. Confirm `FMR_Header.Date_Required` is still the **same date**.

The date must never become 1969.

If the source carries an unreadable or suspicious date, staging should now stop
with a clear Date Required error rather than silently publishing it.
