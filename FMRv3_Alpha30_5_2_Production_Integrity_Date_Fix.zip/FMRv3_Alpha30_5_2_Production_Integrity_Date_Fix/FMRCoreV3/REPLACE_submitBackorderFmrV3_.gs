/**
 * Alpha 30.5.2 COMPLETE REPLACEMENT FUNCTION
 *
 * In FMRCoreV3/FieldService.gs, replace the existing submitBackorderFmrV3_
 * function with this entire function.
 *
 * Change from Alpha 30.5:
 *   Before a new request is created, the function compares the authoritative
 *   FMR_Line_Items pending/confirmed state against active Backorder_Requests.
 *   If they disagree, submission is stopped BEFORE another request is written.
 */
function submitBackorderFmrV3_(
  user,
  line,
  request
) {
  const quantity =
    positiveNumberFmrV3_(
      request.quantity,
      'Backorder quantity'
    );

  const reason =
    normalizeFmrV3_(
      request.reason
    );

  if (!reason) {
    throw new Error(
      'Backorder reason is required.'
    );
  }

  const state =
    lineStateFmrV3_(
      line
    );

  /**
   * Alpha 30.5.2 duplicate-commit guard.
   *
   * This catches the exact failure mode that produced the FMR 209 orphan:
   * a Backorder_Requests row existed, but FMR_Line_Items had not yet reached
   * the same state. A retry is blocked rather than creating another request.
   */
  assertBackorderRequestParityBeforeSubmitAlpha30_5_2_(
    line,
    state
  );

  const maximum =
    fieldNewBackorderQuantityFmrV3_(
      state
    );

  if (
    quantity >
    maximum
  ) {
    throw new Error(
      'Only ' +
      maximum +
      ' can be submitted as a new backorder without duplicating an existing commitment.'
    );
  }

  const requestId =
    uuidFmrV3_(
      'BACKORDER'
    );

  const correlationId =
    uuidFmrV3_(
      'CORR'
    );

  const resubmissionPlan =
    planReturnedBackorderResubmissionFmrV3_(
      line,
      quantity
    );

  applyReturnedBackorderResubmissionFmrV3_(
    line,
    resubmissionPlan,
    user,
    correlationId
  );

  const now =
    nowFmrV3_();

  const requestRow =
    appendObjectFmrV3_(
      FMR_V3.SHEETS
        .BACKORDERS,
      {
        Backorder_Request_ID:
          requestId,

        Correlation_ID:
          correlationId,

        FMR_ID:
          line.FMR_ID,

        FMR_Number:
          line.FMR_Number,

        FMR_Line_ID:
          line.FMR_Line_ID,

        ISO_Key:
          line.ISO_Key,

        Commodity_Code:
          line.Commodity_Code,

        Qty_Requested_Backorder:
          quantity,

        Qty_Confirmed_Backorder:
          0,

        Qty_Pending:
          quantity,

        Reason:
          reason,

        Field_Notes:
          normalizeFmrV3_(
            request.notes
          ),

        Reported_By_Email:
          user.email,

        Reported_By_Name:
          normalizeFmrV3_(
            request
              .performedByName ||
            user.name
          ),

        Reported_At:
          now,

        Status:
          'Pending Admin Review',

        Admin_Decision:
          '',

        Admin_Notes:
          '',

        Decided_By_Email:
          '',

        Decided_By_Name:
          '',

        Decided_At:
          '',

        Returned_Review_Reason:
          '',

        Active:
          FMR_V3.YES,

        Updated_At:
          now
      }
    );

  appendOperationalIndexEntriesFmrV3_([
    {
      Index_Key:
        operationalIndexKeyFmrV3_(
          'BACKORDER',
          requestId
        ),

      Index_Type:
        'BACKORDER',

      Entity_ID:
        requestId,

      Parent_ID:
        line.FMR_Line_ID,

      Row_Number:
        requestRow,

      Secondary_Row_Number:
        line._rowNumber,

      Active:
        FMR_V3.YES,

      Updated_At:
        now
    },
    {
      Index_Key:
        operationalIndexKeyFmrV3_(
          'BACKORDERSTATUS',
          'Pending Admin Review'
        ),

      Index_Type:
        'BACKORDERSTATUS',

      Entity_ID:
        requestId,

      Parent_ID:
        line.FMR_Line_ID,

      Row_Number:
        requestRow,

      Secondary_Row_Number:
        line._rowNumber,

      Active:
        FMR_V3.YES,

      Updated_At:
        now
    },
    {
      Index_Key:
        operationalIndexKeyFmrV3_(
          'BACKORDERLINE',
          line.FMR_Line_ID
        ),

      Index_Type:
        'BACKORDERLINE',

      Entity_ID:
        requestId,

      Parent_ID:
        line.FMR_Line_ID,

      Row_Number:
        requestRow,

      Secondary_Row_Number:
        line._rowNumber,

      Active:
        FMR_V3.YES,

      Updated_At:
        now
    }
  ]);

  upsertFieldNotificationFromBackorderFmrV3_(
    {
      _rowNumber:
        requestRow,

      Backorder_Request_ID:
        requestId,

      FMR_ID:
        line.FMR_ID,

      FMR_Number:
        line.FMR_Number,

      FMR_Line_ID:
        line.FMR_Line_ID,

      Qty_Requested_Backorder:
        quantity,

      Qty_Confirmed_Backorder:
        0,

      Qty_Pending:
        quantity,

      Reason:
        reason,

      Status:
        'Pending Admin Review',

      Active:
        FMR_V3.YES,

      Updated_At:
        now
    },
    line,
    {
      timestamp:
        now
    }
  );

  state.pendingBackorder +=
    quantity;

  appendTransactionFmrV3_(
    line,
    'BACKORDER_REQUESTED',
    quantity,
    user,
    {
      correlationId:
        correlationId,

      backorderRequestId:
        requestId,

      performedByName:
        request.performedByName,

      notes:
        reason +
        '. ' +
        normalizeFmrV3_(
          request.notes
        )
    }
  );

  return finishLineActionFmrV3_(
    user,
    line,
    state,
    'BACKORDER_REQUESTED',
    correlationId,
    {
      requestId:
        requestId,

      quantity:
        quantity,

      rejectedNoticeResolutionQuantity:
        quantity,

      reason:
        reason,

      resubmittedReturnedQuantity:
        resubmissionPlan
          .resubmittedQuantity,

      message:
        quantity +
        ' ' +
        line.UOM +
        ' submitted for Admin backorder review.'
    }
  );
}
