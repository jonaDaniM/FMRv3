# 04 — Rollback

## Code rollback

The package baseline is GitHub commit:

`771412f8f0f04f4f70d1ffd5e3460ffbec67b5e8`

If the new code must be backed out:

1. Point the Bound project back to the prior immutable Core library version
   `37`.
2. Redeploy the existing Bound web-app deployment.
3. Restore `Bound/Client.html` from the baseline commit if the Bound UI change
   must also be removed.

Because the old Core library version is immutable, rolling Bound back to
version 37 restores the previous runtime behavior without deleting the new
Core source.

## Data rollback

`applyAlpha30_5_2ProductionRepair()` creates a fresh Production database backup
before making any repair.

Do not restore the entire database merely because the portal has a code issue.
Prefer code rollback first.

A full database restore should only be considered if the repair itself wrote
incorrect data.

Expected repair writes are intentionally narrow:

### FMR 209

- one Backorder_Requests row made inactive/Voided;
- Operational_Index rows for that orphan entity made inactive;
- Field notification reconciliation;
- header refresh;
- Audit_Log entry.

The correct FMR_Line_Items pending quantity is not changed.

### Date repair

Only Date_Required is corrected on the known eligible FMR_Header and linked
Import_Staging_Header rows, plus Updated fields and Audit_Log entries.

No quantities, material lines, transactions, Bag records, or valid backorder
requests are rewritten.

## If Preview blocks

Do not "force" the repair by editing the guard constants.

A blocked preview means Production changed from the evidence used to construct
this package. Capture the JSON output and reconcile that specific record first.
