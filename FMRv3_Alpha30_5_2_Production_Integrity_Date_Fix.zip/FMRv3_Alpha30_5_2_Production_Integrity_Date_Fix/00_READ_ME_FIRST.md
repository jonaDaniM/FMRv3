# FMR Operations v3 — Alpha 30.5.2 Production Integrity + Date Fix

## What this package fixes

This package is based on GitHub commit:

`771412f8f0f04f4f70d1ffd5e3460ffbec67b5e8`

Current Core version at that commit:

`3.0.0-alpha.30.5`

Current Bound library reference at that commit:

`FMRCoreV3 version 37`

The package fixes two production defects that were verified against the live
Production database fingerprint `Pbbv5bSG3STZ`.

### Defect A — Operational Readiness shows FAIL

The FAIL is **not** being caused by stale backorders. The current Production
dashboard showed:

- Stale B/O = 0
- Stale Bags = 0
- Latest backup = SUCCESS
- Production transaction mode = ENABLED

The hard failure was caused by an integrity mismatch on:

- FMR 209
- FMR line ID `FMRLINE-9FCBEEC9-5789-4A95-B0BA-F23305F788A8`
- Commodity `5FSH8-A-L-1`
- Correct line state = 3 EA pending backorder

Two active Backorder_Requests existed for the same 3 EA commitment.

Orphan request to retire:

`BACKORDER-49F182BB-C569-402C-9617-1DFF70D94A5A`

Authoritative completed request to keep:

`BACKORDER-4622291F-A57C-4B66-B68F-BD82AD37DCBB`

The orphan has no corresponding BACKORDER_REQUESTED material transaction.
The keeper does.

The repair retires the orphan request and its active Operational_Index entries.
It does **not** change the correct 3 EA pending quantity on FMR 209.

### Defect B — Date Required becomes 12/31/1969

The Bulk Import parser is reading the dates correctly. The corruption occurs
when a native JavaScript `Date` object is passed into the current staging
validator, which assumes Date Required is a string and does this:

`new Date(`${source.dateRequired}T12:00:00`)`

Alpha 30.5.2 replaces that conversion with a safe normalizer that understands:

- a native Date object returned by `SpreadsheetApp.getValues()`, and
- a `YYYY-MM-DD` browser/manual-staging string.

The helper also rejects dates outside 2000-01-01 through 2100-12-31 so an
epoch-era date cannot silently publish again.

## Known Production date repairs included

The one-time repair is limited to these 19 FMRs because their source
Bulk_Import_Items dates were verified and their published/staging dates carry
the known 1969 defect:

- 653, 654, 655, 656, 657, 658 → 2026-07-24
- 666 → 2026-07-21
- 667, 668, 669 → 2026-07-24
- 670, 671, 672, 673, 674 → 2026-07-27
- 791 → 2026-08-10
- 811, 812 → 2026-08-18
- 930 → 2026-08-27

FMR 803 is deliberately **not** auto-repaired. Its source says 2026-07-23
while published/staging says 2026-07-26. That is a separate discrepancy and
requires a source-document check before changing Production.

## Package contents

### FMRCoreV3

`ADD_Alpha30_5_2_ProductionHardening.gs`
: New permanent Core file. Contains Date Required normalization, Field
  backorder parity guard, owner-only Production repair, and repair diagnostics.

`REPLACE_validateStagePayloadFmrV3_.gs`
: Complete replacement function for `OwnerService.gs`.

`REPLACE_submitBackorderFmrV3_.gs`
: Complete replacement function for `FieldService.gs`.

`REPLACE_Config_VERSION.txt`
: Exact Core version-string change.

### Bound

`REPLACE_Operational_Readiness_Fail_Message.txt`
: Exact Client.html UI replacement so FAIL explains the actual hard failure
  instead of saying all controls are healthy.

### Documentation

`01_IMPLEMENTATION_INSTRUCTIONS.md`
: Exact copy/paste and deployment sequence.

`02_PRODUCTION_REPAIR_RUNBOOK.md`
: Preview/apply procedure and expected results.

`03_VALIDATION_CHECKLIST.md`
: Post-change functional and Production verification.

`04_ROLLBACK.md`
: How to back out code and how the automatic pre-repair backup is used.

## Important execution rule

Run the **Preview** first.

Do not run Apply if Preview reports:

- `dateRepair.blocked > 0`, or
- `orphanBackorder.blocked = true`.

The Apply function itself checks these conditions again and refuses to write
if they changed after Preview.
