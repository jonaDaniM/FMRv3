# Known Production Repair Targets

## Database guard

- Spreadsheet: FMR Operations Database v3 - PRODUCTION
- Spreadsheet ID: `1dB9drNelT2D9OCy6tUyzGrqta4CBFC6P-x2WTlCLb4E`
- Runtime fingerprint: `Pbbv5bSG3STZ`

## Date Required

| FMR | Verified Bulk Import source date | Automatic action |
|---:|:---:|:---|
| 653 | 2026-07-24 | Repair epoch date |
| 654 | 2026-07-24 | Repair epoch date |
| 655 | 2026-07-24 | Repair epoch date |
| 656 | 2026-07-24 | Repair epoch date |
| 657 | 2026-07-24 | Repair epoch date |
| 658 | 2026-07-24 | Repair epoch date |
| 666 | 2026-07-21 | Repair epoch date |
| 667 | 2026-07-24 | Repair epoch date |
| 668 | 2026-07-24 | Repair epoch date |
| 669 | 2026-07-24 | Repair epoch date |
| 670 | 2026-07-27 | Repair epoch date |
| 671 | 2026-07-27 | Repair epoch date |
| 672 | 2026-07-27 | Repair epoch date |
| 673 | 2026-07-27 | Repair epoch date |
| 674 | 2026-07-27 | Repair epoch date |
| 791 | 2026-08-10 | Repair epoch date |
| 811 | 2026-08-18 | Repair epoch date |
| 812 | 2026-08-18 | Repair epoch date |
| 930 | 2026-08-27 | Repair epoch date |
| 803 | Source 2026-07-23; published 2026-07-26 | **Manual review only — no automatic change** |

## FMR 209 orphan backorder

Target line:

`FMRLINE-9FCBEEC9-5789-4A95-B0BA-F23305F788A8`

Commodity:

`5FSH8-A-L-1`

Correct line state:

- requested 3 EA
- pending backorder 3 EA
- confirmed backorder 0
- not yet located 3 EA
- remaining 3 EA

Retire:

`BACKORDER-49F182BB-C569-402C-9617-1DFF70D94A5A`

Keep:

`BACKORDER-4622291F-A57C-4B66-B68F-BD82AD37DCBB`

The repair never deletes either request row.
